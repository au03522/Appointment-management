﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project
{
    public partial class d_main_page_viewdetails : Form
    {
        SqlConnection con1;
        public int caseID =0;
        public d_main_page_viewdetails()
        {
            InitializeComponent();
        }

        private void IC_appdate_label_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void d_main_page_viewdetails_Load(object sender, EventArgs e)
        {
            //con1 = new SqlConnection("Data Source =.; Initial Catalog = PMS; User ID = sa; Password=Habib123##");
            con1 = new SqlConnection("Data Source=ADMIN-PC;Initial Catalog=ams;Integrated Security=True");
            con1.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select PatientName from Patient p, InstructCase ic where ic.Patient_idPatient=p.idPatient and idCase = " + Convert.ToInt32(caseID);
            dmain_viewdetails_name_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select gender from Patient p, InstructCase ic where ic.Patient_idPatient=p.idPatient and idCase =" + Convert.ToInt32(caseID);
            dmain_viewdetails_gender_tbx.Text = cmd.ExecuteScalar().ToString();
            dmain_viewdetails_caseID_tbx.Text = caseID.ToString();
            try
            {
                cmd.CommandText = "select PreferredDate from InstructCase where idCase =" + caseID;
                IC_prefappdate_dtp.Text = cmd.ExecuteScalar().ToString();
                cmd.CommandText = "select idAppointment from Appointment where InstructCase_idCase = " + Convert.ToInt32(caseID);
                dmain_viewdetails_appID_tbx.Text = cmd.ExecuteScalar().ToString();
                cmd.CommandText = "select AppDatenTime from Appointment where InstructCase_idCase = " + Convert.ToInt32(caseID);
                IC_appointed_dtp.Text = cmd.ExecuteScalar().ToString();
                cmd.CommandText = "select ConfirmationStatus from Appointment where InstructCase_idCase = " + Convert.ToInt32(caseID);
                dmain_viewdetails_confirmStatus_tbx.Text = cmd.ExecuteScalar().ToString();
            }
            catch
            {
                IC_prefappdate_dtp.Text = "1900-1-1";
            }
            cmd.CommandText = "select appointmentstatus from InstructCase where idCase =" + caseID;
            dmain_viewdetails_appStatus_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select caseType from InstructCase where idCase =" + caseID;
            dmain_viewdetails_casetype_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select casedetails from InstructCase where idCase =" + caseID;
            IC_casedetails_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select specialinstructions from InstructCase where idCase =" + caseID;
            IC_specialinstruction_tbx.Text = cmd.ExecuteScalar().ToString();
            dmain_viewdetails_name_tbx.Enabled = false;
            dmain_viewdetails_gender_tbx.Enabled = false;
            dmain_viewdetails_caseID_tbx.Enabled = false;
            dmain_viewdetails_appID_tbx.Enabled = false;
            dmain_viewdetails_appStatus_tbx.Enabled = false;
            IC_appointed_dtp.Enabled = false;
            IC_prefappdate_dtp.Enabled = false;
            IC_dateaccident_dtp.Enabled = false;
            dmain_viewdetails_confirmStatus_tbx.Enabled = false;
            IC_specialinstruction_tbx.Enabled = false;
            IC_casedetails_tbx.Enabled = false;
            dmain_viewdetails_casetype_tbx.Enabled = false;
        }

        private void dmain_viewdetails_editApp_b_Click(object sender, EventArgs e)
        {
            IC_appointed_dtp.Enabled = true;
        }

        private void dmain_viewdetails_close_b_Click(object sender, EventArgs e)
        {
            string selectDateAsString = IC_appointed_dtp.Value.ToString("yyyy-MM-dd");
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Update appointment set AppDatenTime = '" + selectDateAsString + "'where instructcase_idcase = " + caseID;
            cmd.ExecuteScalar();
            this.Close();
        }
    }
}
