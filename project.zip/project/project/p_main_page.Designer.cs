﻿namespace project
{
    partial class p_main_page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.p_emergencynum_tbx = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.p_specialinstructions_tbx = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.p_casetype_tbx = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.IC_casedetails_tbx = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.d_main_confirm_b = new System.Windows.Forms.Button();
            this.d_main_reject_b = new System.Windows.Forms.Button();
            this.dmain_appStatus_tbx = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.d_main_appointment_date_dtp = new System.Windows.Forms.DateTimePicker();
            this.d_main_caseID_combo = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.d_main_appointmentID_tbx = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.d_main_doctor_name_tbx = new System.Windows.Forms.TextBox();
            this.patienthome_instruct_b = new System.Windows.Forms.Button();
            this.registerasdoctor_clinic1_gbx = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.p_emergencyname_tbx = new System.Windows.Forms.MaskedTextBox();
            this.d_main_editinfo_b = new System.Windows.Forms.Button();
            this.d_main_gender_o_rb = new System.Windows.Forms.RadioButton();
            this.d_main_gender_f_rb = new System.Windows.Forms.RadioButton();
            this.d_main_gender_m_rb = new System.Windows.Forms.RadioButton();
            this.label18 = new System.Windows.Forms.Label();
            this.d_main_general_save_b = new System.Windows.Forms.Button();
            this.d_main_email_tbx = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.d_main_number_tbx = new System.Windows.Forms.TextBox();
            this.d_main_doctor_address_tbx = new System.Windows.Forms.TextBox();
            this.d_main_patient_name_tbx = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.register2_address_label = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.p_signout_b = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.registerasdoctor_clinic1_gbx.SuspendLayout();
            this.SuspendLayout();
            // 
            // p_emergencynum_tbx
            // 
            this.p_emergencynum_tbx.Location = new System.Drawing.Point(99, 170);
            this.p_emergencynum_tbx.Name = "p_emergencynum_tbx";
            this.p_emergencynum_tbx.Size = new System.Drawing.Size(149, 20);
            this.p_emergencynum_tbx.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 170);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 15);
            this.label1.TabIndex = 20;
            this.label1.Text = "Emergency No:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.p_specialinstructions_tbx);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.p_casetype_tbx);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.IC_casedetails_tbx);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.d_main_confirm_b);
            this.groupBox2.Controls.Add(this.d_main_reject_b);
            this.groupBox2.Controls.Add(this.dmain_appStatus_tbx);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.d_main_appointment_date_dtp);
            this.groupBox2.Controls.Add(this.d_main_caseID_combo);
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label43);
            this.groupBox2.Controls.Add(this.d_main_appointmentID_tbx);
            this.groupBox2.Controls.Add(this.label42);
            this.groupBox2.Controls.Add(this.d_main_doctor_name_tbx);
            this.groupBox2.Location = new System.Drawing.Point(284, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(305, 318);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "My cases";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // p_specialinstructions_tbx
            // 
            this.p_specialinstructions_tbx.Location = new System.Drawing.Point(107, 230);
            this.p_specialinstructions_tbx.Name = "p_specialinstructions_tbx";
            this.p_specialinstructions_tbx.Size = new System.Drawing.Size(186, 51);
            this.p_specialinstructions_tbx.TabIndex = 93;
            this.p_specialinstructions_tbx.Text = "";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(11, 212);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 91;
            this.label3.Text = "Case Type:";
            // 
            // p_casetype_tbx
            // 
            this.p_casetype_tbx.Location = new System.Drawing.Point(107, 204);
            this.p_casetype_tbx.Name = "p_casetype_tbx";
            this.p_casetype_tbx.Size = new System.Drawing.Size(186, 20);
            this.p_casetype_tbx.TabIndex = 90;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 240);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 13);
            this.label5.TabIndex = 92;
            this.label5.Text = "Special Instructions:";
            // 
            // IC_casedetails_tbx
            // 
            this.IC_casedetails_tbx.Location = new System.Drawing.Point(108, 150);
            this.IC_casedetails_tbx.Name = "IC_casedetails_tbx";
            this.IC_casedetails_tbx.Size = new System.Drawing.Size(186, 51);
            this.IC_casedetails_tbx.TabIndex = 88;
            this.IC_casedetails_tbx.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label6.Location = new System.Drawing.Point(7, 153);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 87;
            this.label6.Text = "Case details:";
            // 
            // d_main_confirm_b
            // 
            this.d_main_confirm_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_confirm_b.Location = new System.Drawing.Point(108, 281);
            this.d_main_confirm_b.Name = "d_main_confirm_b";
            this.d_main_confirm_b.Size = new System.Drawing.Size(91, 29);
            this.d_main_confirm_b.TabIndex = 86;
            this.d_main_confirm_b.Text = "Confirm ";
            this.d_main_confirm_b.UseVisualStyleBackColor = true;
            this.d_main_confirm_b.Click += new System.EventHandler(this.d_main_confirm_b_Click);
            // 
            // d_main_reject_b
            // 
            this.d_main_reject_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_reject_b.Location = new System.Drawing.Point(203, 281);
            this.d_main_reject_b.Name = "d_main_reject_b";
            this.d_main_reject_b.Size = new System.Drawing.Size(91, 29);
            this.d_main_reject_b.TabIndex = 85;
            this.d_main_reject_b.Text = "Reject";
            this.d_main_reject_b.UseVisualStyleBackColor = true;
            this.d_main_reject_b.Click += new System.EventHandler(this.d_main_reject_b_Click);
            // 
            // dmain_appStatus_tbx
            // 
            this.dmain_appStatus_tbx.Location = new System.Drawing.Point(108, 124);
            this.dmain_appStatus_tbx.Name = "dmain_appStatus_tbx";
            this.dmain_appStatus_tbx.Size = new System.Drawing.Size(186, 20);
            this.dmain_appStatus_tbx.TabIndex = 84;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label4.Location = new System.Drawing.Point(6, 127);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 83;
            this.label4.Text = "Appointment Status:";
            // 
            // d_main_appointment_date_dtp
            // 
            this.d_main_appointment_date_dtp.CustomFormat = "yyyy-MM-dd hh:mm";
            this.d_main_appointment_date_dtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.d_main_appointment_date_dtp.Location = new System.Drawing.Point(108, 98);
            this.d_main_appointment_date_dtp.Name = "d_main_appointment_date_dtp";
            this.d_main_appointment_date_dtp.Size = new System.Drawing.Size(186, 20);
            this.d_main_appointment_date_dtp.TabIndex = 57;
            // 
            // d_main_caseID_combo
            // 
            this.d_main_caseID_combo.FormattingEnabled = true;
            this.d_main_caseID_combo.Location = new System.Drawing.Point(108, 19);
            this.d_main_caseID_combo.Name = "d_main_caseID_combo";
            this.d_main_caseID_combo.Size = new System.Drawing.Size(186, 21);
            this.d_main_caseID_combo.TabIndex = 52;
            this.d_main_caseID_combo.SelectedIndexChanged += new System.EventHandler(this.d_main_caseID_combo_SelectedIndexChanged);
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(12, 52);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(83, 13);
            this.label44.TabIndex = 58;
            this.label44.Text = "Appointment ID:";
            this.label44.Click += new System.EventHandler(this.label44_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(7, 104);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(95, 13);
            this.label40.TabIndex = 63;
            this.label40.Text = "Appointment Date:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(12, 22);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(48, 13);
            this.label43.TabIndex = 59;
            this.label43.Text = "Case ID:";
            // 
            // d_main_appointmentID_tbx
            // 
            this.d_main_appointmentID_tbx.Location = new System.Drawing.Point(108, 46);
            this.d_main_appointmentID_tbx.Name = "d_main_appointmentID_tbx";
            this.d_main_appointmentID_tbx.Size = new System.Drawing.Size(186, 20);
            this.d_main_appointmentID_tbx.TabIndex = 54;
            this.d_main_appointmentID_tbx.TextChanged += new System.EventHandler(this.d_main_appointmentID_tbx_TextChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(12, 80);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(73, 13);
            this.label42.TabIndex = 60;
            this.label42.Text = "Doctor Name:";
            // 
            // d_main_doctor_name_tbx
            // 
            this.d_main_doctor_name_tbx.Location = new System.Drawing.Point(108, 72);
            this.d_main_doctor_name_tbx.Name = "d_main_doctor_name_tbx";
            this.d_main_doctor_name_tbx.Size = new System.Drawing.Size(186, 20);
            this.d_main_doctor_name_tbx.TabIndex = 53;
            // 
            // patienthome_instruct_b
            // 
            this.patienthome_instruct_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.patienthome_instruct_b.Location = new System.Drawing.Point(595, 23);
            this.patienthome_instruct_b.Name = "patienthome_instruct_b";
            this.patienthome_instruct_b.Size = new System.Drawing.Size(91, 29);
            this.patienthome_instruct_b.TabIndex = 60;
            this.patienthome_instruct_b.Text = "Instruct Case";
            this.patienthome_instruct_b.UseVisualStyleBackColor = true;
            this.patienthome_instruct_b.Click += new System.EventHandler(this.patienthome_instruct_b_Click);
            // 
            // registerasdoctor_clinic1_gbx
            // 
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label2);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.p_emergencyname_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_editinfo_b);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_gender_o_rb);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.p_emergencynum_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label1);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_gender_f_rb);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_gender_m_rb);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label18);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_general_save_b);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_email_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label16);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_number_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_doctor_address_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.d_main_patient_name_tbx);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label17);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.register2_address_label);
            this.registerasdoctor_clinic1_gbx.Controls.Add(this.label7);
            this.registerasdoctor_clinic1_gbx.Location = new System.Drawing.Point(12, 12);
            this.registerasdoctor_clinic1_gbx.Name = "registerasdoctor_clinic1_gbx";
            this.registerasdoctor_clinic1_gbx.Size = new System.Drawing.Size(266, 245);
            this.registerasdoctor_clinic1_gbx.TabIndex = 111;
            this.registerasdoctor_clinic1_gbx.TabStop = false;
            this.registerasdoctor_clinic1_gbx.Text = "General";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(-3, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 15);
            this.label2.TabIndex = 80;
            this.label2.Text = "Emergency Name:";
            // 
            // p_emergencyname_tbx
            // 
            this.p_emergencyname_tbx.Location = new System.Drawing.Point(99, 144);
            this.p_emergencyname_tbx.Name = "p_emergencyname_tbx";
            this.p_emergencyname_tbx.Size = new System.Drawing.Size(149, 20);
            this.p_emergencyname_tbx.TabIndex = 79;
            // 
            // d_main_editinfo_b
            // 
            this.d_main_editinfo_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_editinfo_b.Location = new System.Drawing.Point(106, 216);
            this.d_main_editinfo_b.Name = "d_main_editinfo_b";
            this.d_main_editinfo_b.Size = new System.Drawing.Size(154, 23);
            this.d_main_editinfo_b.TabIndex = 78;
            this.d_main_editinfo_b.Text = "Edit Information";
            this.d_main_editinfo_b.UseVisualStyleBackColor = true;
            this.d_main_editinfo_b.Click += new System.EventHandler(this.d_main_editinfo_b_Click);
            // 
            // d_main_gender_o_rb
            // 
            this.d_main_gender_o_rb.AutoSize = true;
            this.d_main_gender_o_rb.Location = new System.Drawing.Point(204, 71);
            this.d_main_gender_o_rb.Name = "d_main_gender_o_rb";
            this.d_main_gender_o_rb.Size = new System.Drawing.Size(49, 17);
            this.d_main_gender_o_rb.TabIndex = 77;
            this.d_main_gender_o_rb.TabStop = true;
            this.d_main_gender_o_rb.Text = "other";
            this.d_main_gender_o_rb.UseVisualStyleBackColor = true;
            // 
            // d_main_gender_f_rb
            // 
            this.d_main_gender_f_rb.AutoSize = true;
            this.d_main_gender_f_rb.Location = new System.Drawing.Point(154, 71);
            this.d_main_gender_f_rb.Name = "d_main_gender_f_rb";
            this.d_main_gender_f_rb.Size = new System.Drawing.Size(28, 17);
            this.d_main_gender_f_rb.TabIndex = 76;
            this.d_main_gender_f_rb.TabStop = true;
            this.d_main_gender_f_rb.Text = "f";
            this.d_main_gender_f_rb.UseVisualStyleBackColor = true;
            // 
            // d_main_gender_m_rb
            // 
            this.d_main_gender_m_rb.AutoSize = true;
            this.d_main_gender_m_rb.Location = new System.Drawing.Point(99, 71);
            this.d_main_gender_m_rb.Name = "d_main_gender_m_rb";
            this.d_main_gender_m_rb.Size = new System.Drawing.Size(33, 17);
            this.d_main_gender_m_rb.TabIndex = 46;
            this.d_main_gender_m_rb.TabStop = true;
            this.d_main_gender_m_rb.Text = "m";
            this.d_main_gender_m_rb.UseVisualStyleBackColor = true;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(6, 71);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 15);
            this.label18.TabIndex = 75;
            this.label18.Text = "Gender:";
            // 
            // d_main_general_save_b
            // 
            this.d_main_general_save_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.d_main_general_save_b.Location = new System.Drawing.Point(9, 216);
            this.d_main_general_save_b.Name = "d_main_general_save_b";
            this.d_main_general_save_b.Size = new System.Drawing.Size(91, 23);
            this.d_main_general_save_b.TabIndex = 74;
            this.d_main_general_save_b.Text = "Save";
            this.d_main_general_save_b.UseVisualStyleBackColor = true;
            this.d_main_general_save_b.Click += new System.EventHandler(this.d_main_general_save_b_Click);
            // 
            // d_main_email_tbx
            // 
            this.d_main_email_tbx.Location = new System.Drawing.Point(99, 92);
            this.d_main_email_tbx.Name = "d_main_email_tbx";
            this.d_main_email_tbx.Size = new System.Drawing.Size(154, 20);
            this.d_main_email_tbx.TabIndex = 46;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(6, 94);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(42, 15);
            this.label16.TabIndex = 45;
            this.label16.Text = "Email:";
            // 
            // d_main_number_tbx
            // 
            this.d_main_number_tbx.Location = new System.Drawing.Point(99, 43);
            this.d_main_number_tbx.Name = "d_main_number_tbx";
            this.d_main_number_tbx.Size = new System.Drawing.Size(154, 20);
            this.d_main_number_tbx.TabIndex = 40;
            // 
            // d_main_doctor_address_tbx
            // 
            this.d_main_doctor_address_tbx.Location = new System.Drawing.Point(99, 118);
            this.d_main_doctor_address_tbx.Name = "d_main_doctor_address_tbx";
            this.d_main_doctor_address_tbx.Size = new System.Drawing.Size(154, 20);
            this.d_main_doctor_address_tbx.TabIndex = 39;
            // 
            // d_main_patient_name_tbx
            // 
            this.d_main_patient_name_tbx.Location = new System.Drawing.Point(99, 17);
            this.d_main_patient_name_tbx.Name = "d_main_patient_name_tbx";
            this.d_main_patient_name_tbx.Size = new System.Drawing.Size(154, 20);
            this.d_main_patient_name_tbx.TabIndex = 38;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(6, 48);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 15);
            this.label17.TabIndex = 37;
            this.label17.Text = "Contact No:";
            // 
            // register2_address_label
            // 
            this.register2_address_label.AutoSize = true;
            this.register2_address_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_address_label.Location = new System.Drawing.Point(6, 120);
            this.register2_address_label.Name = "register2_address_label";
            this.register2_address_label.Size = new System.Drawing.Size(54, 15);
            this.register2_address_label.TabIndex = 34;
            this.register2_address_label.Text = "Address:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 15);
            this.label7.TabIndex = 11;
            this.label7.Text = "Full Name:";
            // 
            // p_signout_b
            // 
            this.p_signout_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.p_signout_b.Location = new System.Drawing.Point(595, 55);
            this.p_signout_b.Name = "p_signout_b";
            this.p_signout_b.Size = new System.Drawing.Size(91, 29);
            this.p_signout_b.TabIndex = 89;
            this.p_signout_b.Text = "Signout";
            this.p_signout_b.UseVisualStyleBackColor = true;
            this.p_signout_b.Click += new System.EventHandler(this.p_signout_b_Click);
            // 
            // p_main_page
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(709, 342);
            this.Controls.Add(this.p_signout_b);
            this.Controls.Add(this.registerasdoctor_clinic1_gbx);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.patienthome_instruct_b);
            this.Name = "p_main_page";
            this.Text = " Home[Patient]";
            this.Load += new System.EventHandler(this.p_main_page_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.registerasdoctor_clinic1_gbx.ResumeLayout(false);
            this.registerasdoctor_clinic1_gbx.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button patienthome_instruct_b;
        private System.Windows.Forms.MaskedTextBox p_emergencynum_tbx;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox registerasdoctor_clinic1_gbx;
        private System.Windows.Forms.Button d_main_editinfo_b;
        private System.Windows.Forms.RadioButton d_main_gender_o_rb;
        private System.Windows.Forms.RadioButton d_main_gender_f_rb;
        private System.Windows.Forms.RadioButton d_main_gender_m_rb;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button d_main_general_save_b;
        private System.Windows.Forms.TextBox d_main_email_tbx;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox d_main_number_tbx;
        private System.Windows.Forms.TextBox d_main_doctor_address_tbx;
        private System.Windows.Forms.TextBox d_main_patient_name_tbx;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label register2_address_label;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker d_main_appointment_date_dtp;
        private System.Windows.Forms.ComboBox d_main_caseID_combo;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox d_main_appointmentID_tbx;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox d_main_doctor_name_tbx;
        private System.Windows.Forms.Button d_main_confirm_b;
        private System.Windows.Forms.Button d_main_reject_b;
        private System.Windows.Forms.TextBox dmain_appStatus_tbx;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox IC_casedetails_tbx;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox p_emergencyname_tbx;
        private System.Windows.Forms.Button p_signout_b;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox p_casetype_tbx;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox p_specialinstructions_tbx;
    }
}