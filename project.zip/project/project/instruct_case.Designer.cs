﻿namespace project
{
    partial class Instruct_case
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.IC_username_tbx = new System.Windows.Forms.MaskedTextBox();
            this.IC_username_label = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.IC_appdate_dtp = new System.Windows.Forms.DateTimePicker();
            this.IC_request_b = new System.Windows.Forms.Button();
            this.IC_appdate_label = new System.Windows.Forms.Label();
            this.IC_clinicArea_cbx = new System.Windows.Forms.ComboBox();
            this.IC_clinicArea_label = new System.Windows.Forms.Label();
            this.IC_casedate_dtp = new System.Windows.Forms.DateTimePicker();
            this.IC_casedate_label = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.IC_feelingsick_rb = new System.Windows.Forms.RadioButton();
            this.IC_Accident_rb = new System.Windows.Forms.RadioButton();
            this.IC_routine_follow_gbx = new System.Windows.Forms.GroupBox();
            this.IC_routine_rb = new System.Windows.Forms.RadioButton();
            this.IC_follow_rb = new System.Windows.Forms.RadioButton();
            this.IC_doctor_tbx = new System.Windows.Forms.MaskedTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.IC_appointmentID_tbx = new System.Windows.Forms.MaskedTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.IC_feelingsick_gbx = new System.Windows.Forms.GroupBox();
            this.IC_diseasedetails_tbx = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.IC_accident_gbx = new System.Windows.Forms.GroupBox();
            this.IC_casedetails_tbx = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.IC_dateaccident_label = new System.Windows.Forms.Label();
            this.IC_dateaccident_dtp = new System.Windows.Forms.DateTimePicker();
            this.IC_routine_follow_rb = new System.Windows.Forms.RadioButton();
            this.IC_specialinstruction_tbx = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.IC_routine_follow_gbx.SuspendLayout();
            this.IC_feelingsick_gbx.SuspendLayout();
            this.IC_accident_gbx.SuspendLayout();
            this.SuspendLayout();
            // 
            // IC_username_tbx
            // 
            this.IC_username_tbx.Location = new System.Drawing.Point(87, 19);
            this.IC_username_tbx.Name = "IC_username_tbx";
            this.IC_username_tbx.Size = new System.Drawing.Size(195, 20);
            this.IC_username_tbx.TabIndex = 9;
            // 
            // IC_username_label
            // 
            this.IC_username_label.AutoSize = true;
            this.IC_username_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IC_username_label.Location = new System.Drawing.Point(13, 20);
            this.IC_username_label.Name = "IC_username_label";
            this.IC_username_label.Size = new System.Drawing.Size(68, 15);
            this.IC_username_label.TabIndex = 8;
            this.IC_username_label.Text = "Username:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.IC_appdate_dtp);
            this.groupBox1.Controls.Add(this.IC_request_b);
            this.groupBox1.Controls.Add(this.IC_appdate_label);
            this.groupBox1.Controls.Add(this.IC_clinicArea_cbx);
            this.groupBox1.Controls.Add(this.IC_clinicArea_label);
            this.groupBox1.Controls.Add(this.IC_casedate_dtp);
            this.groupBox1.Controls.Add(this.IC_casedate_label);
            this.groupBox1.Controls.Add(this.IC_username_tbx);
            this.groupBox1.Controls.Add(this.IC_username_label);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(896, 96);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            // 
            // IC_appdate_dtp
            // 
            this.IC_appdate_dtp.Location = new System.Drawing.Point(468, 57);
            this.IC_appdate_dtp.Name = "IC_appdate_dtp";
            this.IC_appdate_dtp.Size = new System.Drawing.Size(172, 20);
            this.IC_appdate_dtp.TabIndex = 44;
            // 
            // IC_request_b
            // 
            this.IC_request_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.IC_request_b.Location = new System.Drawing.Point(714, 22);
            this.IC_request_b.Name = "IC_request_b";
            this.IC_request_b.Size = new System.Drawing.Size(175, 61);
            this.IC_request_b.TabIndex = 58;
            this.IC_request_b.Text = "Request Appointment";
            this.IC_request_b.UseVisualStyleBackColor = true;
            this.IC_request_b.Click += new System.EventHandler(this.IC_request_b_Click);
            // 
            // IC_appdate_label
            // 
            this.IC_appdate_label.AutoSize = true;
            this.IC_appdate_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IC_appdate_label.Location = new System.Drawing.Point(302, 57);
            this.IC_appdate_label.Name = "IC_appdate_label";
            this.IC_appdate_label.Size = new System.Drawing.Size(160, 15);
            this.IC_appdate_label.TabIndex = 45;
            this.IC_appdate_label.Text = "Preferred appointment date:";
            // 
            // IC_clinicArea_cbx
            // 
            this.IC_clinicArea_cbx.FormattingEnabled = true;
            this.IC_clinicArea_cbx.Location = new System.Drawing.Point(468, 22);
            this.IC_clinicArea_cbx.Name = "IC_clinicArea_cbx";
            this.IC_clinicArea_cbx.Size = new System.Drawing.Size(172, 21);
            this.IC_clinicArea_cbx.TabIndex = 57;
            // 
            // IC_clinicArea_label
            // 
            this.IC_clinicArea_label.AutoSize = true;
            this.IC_clinicArea_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IC_clinicArea_label.Location = new System.Drawing.Point(300, 20);
            this.IC_clinicArea_label.Name = "IC_clinicArea_label";
            this.IC_clinicArea_label.Size = new System.Drawing.Size(119, 15);
            this.IC_clinicArea_label.TabIndex = 56;
            this.IC_clinicArea_label.Text = "Preffered clinic area:";
            // 
            // IC_casedate_dtp
            // 
            this.IC_casedate_dtp.CustomFormat = "yyyy-MM-dd hh:mm";
            this.IC_casedate_dtp.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.IC_casedate_dtp.Location = new System.Drawing.Point(84, 53);
            this.IC_casedate_dtp.Name = "IC_casedate_dtp";
            this.IC_casedate_dtp.Size = new System.Drawing.Size(198, 20);
            this.IC_casedate_dtp.TabIndex = 51;
            // 
            // IC_casedate_label
            // 
            this.IC_casedate_label.AutoSize = true;
            this.IC_casedate_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IC_casedate_label.Location = new System.Drawing.Point(13, 53);
            this.IC_casedate_label.Name = "IC_casedate_label";
            this.IC_casedate_label.Size = new System.Drawing.Size(36, 15);
            this.IC_casedate_label.TabIndex = 12;
            this.IC_casedate_label.Text = "Date:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.IC_feelingsick_rb);
            this.groupBox2.Controls.Add(this.IC_Accident_rb);
            this.groupBox2.Controls.Add(this.IC_routine_follow_gbx);
            this.groupBox2.Controls.Add(this.IC_feelingsick_gbx);
            this.groupBox2.Controls.Add(this.IC_accident_gbx);
            this.groupBox2.Controls.Add(this.IC_routine_follow_rb);
            this.groupBox2.Location = new System.Drawing.Point(12, 114);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(896, 162);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            // 
            // IC_feelingsick_rb
            // 
            this.IC_feelingsick_rb.AutoSize = true;
            this.IC_feelingsick_rb.Location = new System.Drawing.Point(89, 19);
            this.IC_feelingsick_rb.Name = "IC_feelingsick_rb";
            this.IC_feelingsick_rb.Size = new System.Drawing.Size(83, 17);
            this.IC_feelingsick_rb.TabIndex = 54;
            this.IC_feelingsick_rb.TabStop = true;
            this.IC_feelingsick_rb.Text = "Feeling Sick";
            this.IC_feelingsick_rb.UseVisualStyleBackColor = true;
            this.IC_feelingsick_rb.CheckedChanged += new System.EventHandler(this.IC_feelingsick_rb_CheckedChanged);
            // 
            // IC_Accident_rb
            // 
            this.IC_Accident_rb.AutoSize = true;
            this.IC_Accident_rb.Location = new System.Drawing.Point(16, 19);
            this.IC_Accident_rb.Name = "IC_Accident_rb";
            this.IC_Accident_rb.Size = new System.Drawing.Size(67, 17);
            this.IC_Accident_rb.TabIndex = 53;
            this.IC_Accident_rb.TabStop = true;
            this.IC_Accident_rb.Text = "Accident";
            this.IC_Accident_rb.UseVisualStyleBackColor = true;
            this.IC_Accident_rb.CheckedChanged += new System.EventHandler(this.IC_Accident_rb_CheckedChanged);
            // 
            // IC_routine_follow_gbx
            // 
            this.IC_routine_follow_gbx.Controls.Add(this.IC_routine_rb);
            this.IC_routine_follow_gbx.Controls.Add(this.IC_follow_rb);
            this.IC_routine_follow_gbx.Controls.Add(this.IC_doctor_tbx);
            this.IC_routine_follow_gbx.Controls.Add(this.label15);
            this.IC_routine_follow_gbx.Controls.Add(this.IC_appointmentID_tbx);
            this.IC_routine_follow_gbx.Controls.Add(this.label17);
            this.IC_routine_follow_gbx.Location = new System.Drawing.Point(606, 42);
            this.IC_routine_follow_gbx.Name = "IC_routine_follow_gbx";
            this.IC_routine_follow_gbx.Size = new System.Drawing.Size(283, 111);
            this.IC_routine_follow_gbx.TabIndex = 52;
            this.IC_routine_follow_gbx.TabStop = false;
            this.IC_routine_follow_gbx.Text = "Routine Check up/ Follow up";
            // 
            // IC_routine_rb
            // 
            this.IC_routine_rb.AutoSize = true;
            this.IC_routine_rb.Location = new System.Drawing.Point(6, 19);
            this.IC_routine_rb.Name = "IC_routine_rb";
            this.IC_routine_rb.Size = new System.Drawing.Size(110, 17);
            this.IC_routine_rb.TabIndex = 52;
            this.IC_routine_rb.TabStop = true;
            this.IC_routine_rb.Text = "Routine check up";
            this.IC_routine_rb.UseVisualStyleBackColor = true;
            // 
            // IC_follow_rb
            // 
            this.IC_follow_rb.AutoSize = true;
            this.IC_follow_rb.Location = new System.Drawing.Point(122, 19);
            this.IC_follow_rb.Name = "IC_follow_rb";
            this.IC_follow_rb.Size = new System.Drawing.Size(131, 17);
            this.IC_follow_rb.TabIndex = 51;
            this.IC_follow_rb.TabStop = true;
            this.IC_follow_rb.Text = "Follow up appointment";
            this.IC_follow_rb.UseVisualStyleBackColor = true;
            this.IC_follow_rb.CheckedChanged += new System.EventHandler(this.IC_follow_rb_CheckedChanged);
            // 
            // IC_doctor_tbx
            // 
            this.IC_doctor_tbx.Location = new System.Drawing.Point(128, 82);
            this.IC_doctor_tbx.Name = "IC_doctor_tbx";
            this.IC_doctor_tbx.Size = new System.Drawing.Size(148, 20);
            this.IC_doctor_tbx.TabIndex = 47;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(3, 82);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 15);
            this.label15.TabIndex = 45;
            this.label15.Text = "Doctor:";
            // 
            // IC_appointmentID_tbx
            // 
            this.IC_appointmentID_tbx.Location = new System.Drawing.Point(129, 48);
            this.IC_appointmentID_tbx.Name = "IC_appointmentID_tbx";
            this.IC_appointmentID_tbx.Size = new System.Drawing.Size(148, 20);
            this.IC_appointmentID_tbx.TabIndex = 44;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(3, 50);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(94, 15);
            this.label17.TabIndex = 42;
            this.label17.Text = "Appointment ID:";
            // 
            // IC_feelingsick_gbx
            // 
            this.IC_feelingsick_gbx.Controls.Add(this.IC_diseasedetails_tbx);
            this.IC_feelingsick_gbx.Controls.Add(this.label12);
            this.IC_feelingsick_gbx.Location = new System.Drawing.Point(305, 42);
            this.IC_feelingsick_gbx.Name = "IC_feelingsick_gbx";
            this.IC_feelingsick_gbx.Size = new System.Drawing.Size(295, 111);
            this.IC_feelingsick_gbx.TabIndex = 51;
            this.IC_feelingsick_gbx.TabStop = false;
            this.IC_feelingsick_gbx.Text = "Feeling Sick";
            // 
            // IC_diseasedetails_tbx
            // 
            this.IC_diseasedetails_tbx.Location = new System.Drawing.Point(135, 49);
            this.IC_diseasedetails_tbx.Name = "IC_diseasedetails_tbx";
            this.IC_diseasedetails_tbx.Size = new System.Drawing.Size(148, 51);
            this.IC_diseasedetails_tbx.TabIndex = 65;
            this.IC_diseasedetails_tbx.Text = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(20, 49);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 15);
            this.label12.TabIndex = 42;
            this.label12.Text = "Disease details:";
            // 
            // IC_accident_gbx
            // 
            this.IC_accident_gbx.Controls.Add(this.IC_casedetails_tbx);
            this.IC_accident_gbx.Controls.Add(this.label5);
            this.IC_accident_gbx.Controls.Add(this.IC_dateaccident_label);
            this.IC_accident_gbx.Controls.Add(this.IC_dateaccident_dtp);
            this.IC_accident_gbx.Location = new System.Drawing.Point(16, 42);
            this.IC_accident_gbx.Name = "IC_accident_gbx";
            this.IC_accident_gbx.Size = new System.Drawing.Size(283, 111);
            this.IC_accident_gbx.TabIndex = 3;
            this.IC_accident_gbx.TabStop = false;
            this.IC_accident_gbx.Text = "Accident";
            // 
            // IC_casedetails_tbx
            // 
            this.IC_casedetails_tbx.Location = new System.Drawing.Point(125, 52);
            this.IC_casedetails_tbx.Name = "IC_casedetails_tbx";
            this.IC_casedetails_tbx.Size = new System.Drawing.Size(148, 51);
            this.IC_casedetails_tbx.TabIndex = 48;
            this.IC_casedetails_tbx.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 54);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 15);
            this.label5.TabIndex = 46;
            this.label5.Text = "Case details:";
            // 
            // IC_dateaccident_label
            // 
            this.IC_dateaccident_label.AutoSize = true;
            this.IC_dateaccident_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IC_dateaccident_label.Location = new System.Drawing.Point(6, 23);
            this.IC_dateaccident_label.Name = "IC_dateaccident_label";
            this.IC_dateaccident_label.Size = new System.Drawing.Size(98, 15);
            this.IC_dateaccident_label.TabIndex = 43;
            this.IC_dateaccident_label.Text = "Date of accident:";
            // 
            // IC_dateaccident_dtp
            // 
            this.IC_dateaccident_dtp.Location = new System.Drawing.Point(125, 19);
            this.IC_dateaccident_dtp.Name = "IC_dateaccident_dtp";
            this.IC_dateaccident_dtp.Size = new System.Drawing.Size(148, 20);
            this.IC_dateaccident_dtp.TabIndex = 40;
            // 
            // IC_routine_follow_rb
            // 
            this.IC_routine_follow_rb.AutoSize = true;
            this.IC_routine_follow_rb.Location = new System.Drawing.Point(178, 19);
            this.IC_routine_follow_rb.Name = "IC_routine_follow_rb";
            this.IC_routine_follow_rb.Size = new System.Drawing.Size(225, 17);
            this.IC_routine_follow_rb.TabIndex = 0;
            this.IC_routine_follow_rb.TabStop = true;
            this.IC_routine_follow_rb.Text = "Routine Check up/ Follow up appointment";
            this.IC_routine_follow_rb.UseVisualStyleBackColor = true;
            this.IC_routine_follow_rb.CheckedChanged += new System.EventHandler(this.IC_routine_follow_rb_CheckedChanged);
            // 
            // IC_specialinstruction_tbx
            // 
            this.IC_specialinstruction_tbx.Location = new System.Drawing.Point(163, 296);
            this.IC_specialinstruction_tbx.Name = "IC_specialinstruction_tbx";
            this.IC_specialinstruction_tbx.Size = new System.Drawing.Size(721, 31);
            this.IC_specialinstruction_tbx.TabIndex = 62;
            this.IC_specialinstruction_tbx.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(34, 302);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(116, 15);
            this.label6.TabIndex = 49;
            this.label6.Text = "Special Instructions:";
            // 
            // Instruct_case
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 338);
            this.Controls.Add(this.IC_specialinstruction_tbx);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Instruct_case";
            this.Text = "Instruct case";
            this.Load += new System.EventHandler(this.Instruct_case_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.IC_routine_follow_gbx.ResumeLayout(false);
            this.IC_routine_follow_gbx.PerformLayout();
            this.IC_feelingsick_gbx.ResumeLayout(false);
            this.IC_feelingsick_gbx.PerformLayout();
            this.IC_accident_gbx.ResumeLayout(false);
            this.IC_accident_gbx.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox IC_username_tbx;
        private System.Windows.Forms.Label IC_username_label;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox IC_accident_gbx;
        private System.Windows.Forms.RadioButton IC_routine_follow_rb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label IC_dateaccident_label;
        private System.Windows.Forms.DateTimePicker IC_dateaccident_dtp;
        private System.Windows.Forms.DateTimePicker IC_casedate_dtp;
        private System.Windows.Forms.Label IC_casedate_label;
        private System.Windows.Forms.GroupBox IC_routine_follow_gbx;
        private System.Windows.Forms.MaskedTextBox IC_doctor_tbx;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox IC_feelingsick_gbx;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox IC_casedetails_tbx;
        private System.Windows.Forms.RadioButton IC_routine_rb;
        private System.Windows.Forms.RadioButton IC_follow_rb;
        private System.Windows.Forms.Button IC_request_b;
        private System.Windows.Forms.ComboBox IC_clinicArea_cbx;
        private System.Windows.Forms.Label IC_clinicArea_label;
        private System.Windows.Forms.RichTextBox IC_specialinstruction_tbx;
        private System.Windows.Forms.DateTimePicker IC_appdate_dtp;
        private System.Windows.Forms.Label IC_appdate_label;
        private System.Windows.Forms.RichTextBox IC_diseasedetails_tbx;
        private System.Windows.Forms.RadioButton IC_Accident_rb;
        private System.Windows.Forms.RadioButton IC_feelingsick_rb;
        private System.Windows.Forms.MaskedTextBox IC_appointmentID_tbx;
    }
}