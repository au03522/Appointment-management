﻿namespace project
{
    partial class Register2_Specialization_label
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.register2_contactno_label = new System.Windows.Forms.Label();
            this.register2_dob_label = new System.Windows.Forms.Label();
            this.register2_gender_label = new System.Windows.Forms.Label();
            this.register2_fname_label = new System.Windows.Forms.Label();
            this.register2_contactno_tbx = new System.Windows.Forms.MaskedTextBox();
            this.register2_fname_tbx = new System.Windows.Forms.MaskedTextBox();
            this.register2_female_rb = new System.Windows.Forms.RadioButton();
            this.register2_male_rb = new System.Windows.Forms.RadioButton();
            this.register2_other_rb = new System.Windows.Forms.RadioButton();
            this.register2_dob_dt = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.register2_address_label = new System.Windows.Forms.Label();
            this.register2_address_tbx = new System.Windows.Forms.RichTextBox();
            this.register2_email_tbx = new System.Windows.Forms.MaskedTextBox();
            this.register2_email_label = new System.Windows.Forms.Label();
            this.register2_proceed_b = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.Register2_registeras_gbx = new System.Windows.Forms.GroupBox();
            this.register2_patient_rb = new System.Windows.Forms.RadioButton();
            this.register2_doctor_rb = new System.Windows.Forms.RadioButton();
            this.register2_emno_label = new System.Windows.Forms.Label();
            this.register2_emno_tbx = new System.Windows.Forms.MaskedTextBox();
            this.register2_emname_tbx = new System.Windows.Forms.MaskedTextBox();
            this.register2_emname_label = new System.Windows.Forms.Label();
            this.Register2_registeras_gbx.SuspendLayout();
            this.SuspendLayout();
            // 
            // register2_contactno_label
            // 
            this.register2_contactno_label.AutoSize = true;
            this.register2_contactno_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_contactno_label.Location = new System.Drawing.Point(12, 113);
            this.register2_contactno_label.Name = "register2_contactno_label";
            this.register2_contactno_label.Size = new System.Drawing.Size(70, 15);
            this.register2_contactno_label.TabIndex = 6;
            this.register2_contactno_label.Text = "Contact No:";
            // 
            // register2_dob_label
            // 
            this.register2_dob_label.AutoSize = true;
            this.register2_dob_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_dob_label.Location = new System.Drawing.Point(11, 88);
            this.register2_dob_label.Name = "register2_dob_label";
            this.register2_dob_label.Size = new System.Drawing.Size(77, 15);
            this.register2_dob_label.TabIndex = 7;
            this.register2_dob_label.Text = "Date of Birth:";
            // 
            // register2_gender_label
            // 
            this.register2_gender_label.AutoSize = true;
            this.register2_gender_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_gender_label.Location = new System.Drawing.Point(12, 61);
            this.register2_gender_label.Name = "register2_gender_label";
            this.register2_gender_label.Size = new System.Drawing.Size(51, 15);
            this.register2_gender_label.TabIndex = 9;
            this.register2_gender_label.Text = "Gender:";
            // 
            // register2_fname_label
            // 
            this.register2_fname_label.AutoSize = true;
            this.register2_fname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_fname_label.Location = new System.Drawing.Point(11, 32);
            this.register2_fname_label.Name = "register2_fname_label";
            this.register2_fname_label.Size = new System.Drawing.Size(64, 15);
            this.register2_fname_label.TabIndex = 10;
            this.register2_fname_label.Text = "Full Name";
            // 
            // register2_contactno_tbx
            // 
            this.register2_contactno_tbx.Location = new System.Drawing.Point(95, 112);
            this.register2_contactno_tbx.Name = "register2_contactno_tbx";
            this.register2_contactno_tbx.Size = new System.Drawing.Size(200, 20);
            this.register2_contactno_tbx.TabIndex = 11;
            // 
            // register2_fname_tbx
            // 
            this.register2_fname_tbx.Location = new System.Drawing.Point(95, 31);
            this.register2_fname_tbx.Name = "register2_fname_tbx";
            this.register2_fname_tbx.Size = new System.Drawing.Size(200, 20);
            this.register2_fname_tbx.TabIndex = 15;
            // 
            // register2_female_rb
            // 
            this.register2_female_rb.AutoSize = true;
            this.register2_female_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_female_rb.Location = new System.Drawing.Point(154, 59);
            this.register2_female_rb.Name = "register2_female_rb";
            this.register2_female_rb.Size = new System.Drawing.Size(67, 19);
            this.register2_female_rb.TabIndex = 16;
            this.register2_female_rb.TabStop = true;
            this.register2_female_rb.Text = "Female";
            this.register2_female_rb.UseVisualStyleBackColor = true;
            this.register2_female_rb.CheckedChanged += new System.EventHandler(this.register1_doctor_rb_CheckedChanged);
            // 
            // register2_male_rb
            // 
            this.register2_male_rb.AutoSize = true;
            this.register2_male_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_male_rb.Location = new System.Drawing.Point(95, 59);
            this.register2_male_rb.Name = "register2_male_rb";
            this.register2_male_rb.Size = new System.Drawing.Size(53, 19);
            this.register2_male_rb.TabIndex = 17;
            this.register2_male_rb.TabStop = true;
            this.register2_male_rb.Text = "Male";
            this.register2_male_rb.UseVisualStyleBackColor = true;
            // 
            // register2_other_rb
            // 
            this.register2_other_rb.AutoSize = true;
            this.register2_other_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_other_rb.Location = new System.Drawing.Point(229, 59);
            this.register2_other_rb.Name = "register2_other_rb";
            this.register2_other_rb.Size = new System.Drawing.Size(55, 19);
            this.register2_other_rb.TabIndex = 18;
            this.register2_other_rb.TabStop = true;
            this.register2_other_rb.Text = "Other";
            this.register2_other_rb.UseVisualStyleBackColor = true;
            // 
            // register2_dob_dt
            // 
            this.register2_dob_dt.Location = new System.Drawing.Point(95, 84);
            this.register2_dob_dt.Name = "register2_dob_dt";
            this.register2_dob_dt.Size = new System.Drawing.Size(200, 20);
            this.register2_dob_dt.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 16);
            this.label5.TabIndex = 21;
            this.label5.Text = "Fill in the details to";
            // 
            // register2_address_label
            // 
            this.register2_address_label.AutoSize = true;
            this.register2_address_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_address_label.Location = new System.Drawing.Point(12, 165);
            this.register2_address_label.Name = "register2_address_label";
            this.register2_address_label.Size = new System.Drawing.Size(54, 15);
            this.register2_address_label.TabIndex = 22;
            this.register2_address_label.Text = "Address:";
            // 
            // register2_address_tbx
            // 
            this.register2_address_tbx.Location = new System.Drawing.Point(95, 164);
            this.register2_address_tbx.Name = "register2_address_tbx";
            this.register2_address_tbx.Size = new System.Drawing.Size(200, 51);
            this.register2_address_tbx.TabIndex = 23;
            this.register2_address_tbx.Text = "";
            // 
            // register2_email_tbx
            // 
            this.register2_email_tbx.Location = new System.Drawing.Point(95, 138);
            this.register2_email_tbx.Name = "register2_email_tbx";
            this.register2_email_tbx.Size = new System.Drawing.Size(200, 20);
            this.register2_email_tbx.TabIndex = 24;
            // 
            // register2_email_label
            // 
            this.register2_email_label.AutoSize = true;
            this.register2_email_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_email_label.Location = new System.Drawing.Point(12, 138);
            this.register2_email_label.Name = "register2_email_label";
            this.register2_email_label.Size = new System.Drawing.Size(42, 15);
            this.register2_email_label.TabIndex = 25;
            this.register2_email_label.Text = "Email:";
            this.register2_email_label.Click += new System.EventHandler(this.label7_Click);
            // 
            // register2_proceed_b
            // 
            this.register2_proceed_b.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.register2_proceed_b.Location = new System.Drawing.Point(209, 271);
            this.register2_proceed_b.Name = "register2_proceed_b";
            this.register2_proceed_b.Size = new System.Drawing.Size(84, 29);
            this.register2_proceed_b.TabIndex = 26;
            this.register2_proceed_b.Text = "Proceed";
            this.register2_proceed_b.UseVisualStyleBackColor = true;
            this.register2_proceed_b.Click += new System.EventHandler(this.register2_proceed_b_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(134, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(147, 16);
            this.label8.TabIndex = 27;
            this.label8.Text = "complete registration!";
            // 
            // Register2_registeras_gbx
            // 
            this.Register2_registeras_gbx.Controls.Add(this.register2_patient_rb);
            this.Register2_registeras_gbx.Controls.Add(this.register2_doctor_rb);
            this.Register2_registeras_gbx.Location = new System.Drawing.Point(15, 264);
            this.Register2_registeras_gbx.Name = "Register2_registeras_gbx";
            this.Register2_registeras_gbx.Size = new System.Drawing.Size(172, 38);
            this.Register2_registeras_gbx.TabIndex = 28;
            this.Register2_registeras_gbx.TabStop = false;
            this.Register2_registeras_gbx.Text = "Register as:";
            // 
            // register2_patient_rb
            // 
            this.register2_patient_rb.AutoSize = true;
            this.register2_patient_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_patient_rb.Location = new System.Drawing.Point(105, 13);
            this.register2_patient_rb.Name = "register2_patient_rb";
            this.register2_patient_rb.Size = new System.Drawing.Size(63, 19);
            this.register2_patient_rb.TabIndex = 30;
            this.register2_patient_rb.TabStop = true;
            this.register2_patient_rb.Text = "Patient";
            this.register2_patient_rb.UseVisualStyleBackColor = true;
            // 
            // register2_doctor_rb
            // 
            this.register2_doctor_rb.AutoSize = true;
            this.register2_doctor_rb.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_doctor_rb.Location = new System.Drawing.Point(38, 13);
            this.register2_doctor_rb.Name = "register2_doctor_rb";
            this.register2_doctor_rb.Size = new System.Drawing.Size(61, 19);
            this.register2_doctor_rb.TabIndex = 29;
            this.register2_doctor_rb.TabStop = true;
            this.register2_doctor_rb.Text = "Doctor";
            this.register2_doctor_rb.UseVisualStyleBackColor = true;
            // 
            // register2_emno_label
            // 
            this.register2_emno_label.AutoSize = true;
            this.register2_emno_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_emno_label.Location = new System.Drawing.Point(10, 245);
            this.register2_emno_label.Name = "register2_emno_label";
            this.register2_emno_label.Size = new System.Drawing.Size(91, 15);
            this.register2_emno_label.TabIndex = 32;
            this.register2_emno_label.Text = "Emergency No:";
            // 
            // register2_emno_tbx
            // 
            this.register2_emno_tbx.Location = new System.Drawing.Point(132, 245);
            this.register2_emno_tbx.Name = "register2_emno_tbx";
            this.register2_emno_tbx.Size = new System.Drawing.Size(161, 20);
            this.register2_emno_tbx.TabIndex = 31;
            // 
            // register2_emname_tbx
            // 
            this.register2_emname_tbx.Location = new System.Drawing.Point(132, 219);
            this.register2_emname_tbx.Name = "register2_emname_tbx";
            this.register2_emname_tbx.Size = new System.Drawing.Size(161, 20);
            this.register2_emname_tbx.TabIndex = 30;
            // 
            // register2_emname_label
            // 
            this.register2_emname_label.AutoSize = true;
            this.register2_emname_label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.register2_emname_label.Location = new System.Drawing.Point(10, 220);
            this.register2_emname_label.Name = "register2_emname_label";
            this.register2_emname_label.Size = new System.Drawing.Size(116, 15);
            this.register2_emname_label.TabIndex = 29;
            this.register2_emname_label.Text = "Emergency Contact:";
            // 
            // Register2_Specialization_label
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(299, 303);
            this.ControlBox = false;
            this.Controls.Add(this.register2_emno_label);
            this.Controls.Add(this.register2_emno_tbx);
            this.Controls.Add(this.register2_emname_tbx);
            this.Controls.Add(this.register2_emname_label);
            this.Controls.Add(this.Register2_registeras_gbx);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.register2_proceed_b);
            this.Controls.Add(this.register2_email_label);
            this.Controls.Add(this.register2_email_tbx);
            this.Controls.Add(this.register2_address_tbx);
            this.Controls.Add(this.register2_address_label);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.register2_dob_dt);
            this.Controls.Add(this.register2_other_rb);
            this.Controls.Add(this.register2_male_rb);
            this.Controls.Add(this.register2_female_rb);
            this.Controls.Add(this.register2_fname_tbx);
            this.Controls.Add(this.register2_contactno_tbx);
            this.Controls.Add(this.register2_fname_label);
            this.Controls.Add(this.register2_gender_label);
            this.Controls.Add(this.register2_dob_label);
            this.Controls.Add(this.register2_contactno_label);
            this.Name = "Register2_Specialization_label";
            this.Text = "Sign-up form details";
            this.Load += new System.EventHandler(this.Register2_Load);
            this.Register2_registeras_gbx.ResumeLayout(false);
            this.Register2_registeras_gbx.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label register2_contactno_label;
        private System.Windows.Forms.Label register2_dob_label;
        private System.Windows.Forms.Label register2_gender_label;
        private System.Windows.Forms.Label register2_fname_label;
        private System.Windows.Forms.MaskedTextBox register2_contactno_tbx;
        private System.Windows.Forms.MaskedTextBox register2_fname_tbx;
        private System.Windows.Forms.RadioButton register2_female_rb;
        private System.Windows.Forms.RadioButton register2_male_rb;
        private System.Windows.Forms.RadioButton register2_other_rb;
        private System.Windows.Forms.DateTimePicker register2_dob_dt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label register2_address_label;
        private System.Windows.Forms.RichTextBox register2_address_tbx;
        private System.Windows.Forms.MaskedTextBox register2_email_tbx;
        private System.Windows.Forms.Label register2_email_label;
        private System.Windows.Forms.Button register2_proceed_b;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox Register2_registeras_gbx;
        private System.Windows.Forms.RadioButton register2_patient_rb;
        private System.Windows.Forms.RadioButton register2_doctor_rb;
        private System.Windows.Forms.Label register2_emno_label;
        private System.Windows.Forms.MaskedTextBox register2_emno_tbx;
        private System.Windows.Forms.MaskedTextBox register2_emname_tbx;
        private System.Windows.Forms.Label register2_emname_label;
    }
}