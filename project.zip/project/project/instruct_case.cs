﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace project
{
    public partial class Instruct_case : Form
    {
        SqlConnection con1;
        public int patientID = 0;
        public Instruct_case()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Instruct_case_Load(object sender, EventArgs e)
        {
            con1 = new SqlConnection("Data Source=ADMIN-PC;Initial Catalog=ams;Integrated Security=True");
            con1.Open();
            IC_casedate_dtp.Enabled = false;
            IC_username_tbx.Enabled = false;
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select username from login where patient_idpatient = " + patientID;
            IC_username_tbx.Text = cmd.ExecuteScalar().ToString();
            cmd.CommandText = "select distinct address from clinic";
            SqlDataReader sqlReader = cmd.ExecuteReader();
            while (sqlReader.Read())
            {
                IC_clinicArea_cbx.Items.Add(sqlReader["address"].ToString());
            }
            sqlReader.Close();

        }

        private void IC_routine_follow_rb_CheckedChanged(object sender, EventArgs e)
        {
            IC_accident_gbx.Enabled = false;
            IC_feelingsick_gbx.Enabled = false;
            IC_routine_follow_gbx.Enabled = true;
        }

        private void IC_Accident_rb_CheckedChanged(object sender, EventArgs e)
        {
            IC_accident_gbx.Enabled = true;
            IC_feelingsick_gbx.Enabled = false;
            IC_routine_follow_gbx.Enabled = false;
        }

        private void IC_feelingsick_rb_CheckedChanged(object sender, EventArgs e)
        {
            IC_accident_gbx.Enabled = false;
            IC_feelingsick_gbx.Enabled = true;
            IC_routine_follow_gbx.Enabled = false;
        }

        private void IC_request_b_Click(object sender, EventArgs e)
        {
            string caseDate = IC_casedate_dtp.Value.ToString("yyyy-MM-dd");
            string accidentDate = IC_dateaccident_dtp.Value.ToString("yyyy-MM-dd");
            string preferredDate = IC_appdate_dtp.Value.ToString("yyyy-MM-dd");
            string casetype = " ";
            string casedetails = " ";
            if (IC_Accident_rb.Checked)
            {
                casetype = "accident";
                casedetails = IC_casedetails_tbx.Text;
            }
            else if (IC_feelingsick_rb.Checked)
            {
                casetype = "feeling sick";
                casedetails = IC_diseasedetails_tbx.Text;
            }
            else if (IC_routine_rb.Checked)
            {
                casetype = "routine checkup";
            }
            else if (IC_follow_rb.Checked)
            {
                casetype = "follow up";
            }
            else
            {
                MessageBox.Show("Select a type!");
            }
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            try
            {
                cmd.CommandText = "insert into instructcase (Patient_idPatient,CaseDateTime,AccidentDateTime,CaseType,CaseDetails,AppointmentStatus,preferreddate,preferredArea,specialinstructions) values " +
                    "(" + patientID + ",'" + caseDate + "','" + accidentDate + "','" + casetype + "','" + casedetails + "','unappointed','" + preferredDate + "','" + IC_clinicArea_cbx.Text + "','" + IC_specialinstruction_tbx.Text + "')";
                cmd.ExecuteScalar();
                MessageBox.Show("Case Created Successfully!");
                this.Close();
            }
            catch
            {
                MessageBox.Show("Invalid Details!");
            }
        }

        private void IC_routine_rb_CheckedChanged(object sender, EventArgs e)
        {
            IC_doctor_tbx.Enabled = false;
            IC_appointmentID_tbx.Enabled = false;
        }

        private void IC_follow_rb_CheckedChanged(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con1;
            cmd.CommandType = CommandType.Text;
            try
            {
                cmd.CommandText = "select top 1 idappointment from appointment where patient =" + patientID + "order by appointmentID desc";
                string appIDstr = cmd.ExecuteScalar().ToString();
                int appID = Convert.ToInt32(appIDstr);
                IC_appointmentID_tbx.Text = appIDstr;
                cmd.CommandText = "select doctorname from appointment a, doctor d, where d.iddoctor = a.doctor_iddoctor and idappointment = " + appID;
                IC_doctor_tbx.Text = cmd.ExecuteScalar().ToString();
            }
            catch
            {
                MessageBox.Show("You have not taken any previous appointment!");
            }
        }
    }
}
